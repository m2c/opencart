<?php

class ModelExtensionPaymentKiplepay extends Model {

	public function install() {}

	public function uninstall() {}
}
