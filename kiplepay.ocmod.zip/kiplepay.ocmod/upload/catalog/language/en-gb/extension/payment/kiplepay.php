<?php
// Text
$_['text_title'] = 'Kiplepay';
$_['text_recurring']                    = '%s every %s %s';
$_['text_length']                       = ' for %s payments';